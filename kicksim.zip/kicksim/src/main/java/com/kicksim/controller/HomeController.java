package com.kicksim.controller;

public class HomeController {

}
